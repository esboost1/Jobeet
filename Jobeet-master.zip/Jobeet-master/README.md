# Jobeet FR : Le tutoriel pour Symfony2 en français

* [Website](http://jobeet.thuau.fr/)
* [License](MIT)

* [Dragos Holban] (http://www.ens.ro/2012/03/21/jobeet-tutorial-with-symfony2/) (Auteur original)
* [Jonathan Thuau] (http://jonathan.thuau.fr/) (Traduction FR)